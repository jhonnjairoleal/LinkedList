
package linked;

import javax.swing.JOptionPane;
import java.util.LinkedList;

public class Linked {

    
    public static void main(String[] args) {
        
         LinkedList<String> myList=new LinkedList<String>();
                Integer menu;

                do{
                        menu = Integer.parseInt(JOptionPane.showInputDialog("Menu\n\n"
                                + "1 Insertar a la izquierda\n"
                                + "2 Insertar a la derecha\n"
                                + "3 Eliminar a la izquierda\n"
                                + "4 Eliminar a la derecha\n"
                                + "5 Borrar toda la lista\n"
                                + "6 Mostrar toda la lista\n"
                                + "7 Salir"));
                        switch (menu)
                        {       
                                case 1:
                                        myList.addFirst(JOptionPane.showInputDialog("introduce el valor a agregar"));
                                        JOptionPane.showMessageDialog(null,""+myList);
                                        break;  
                                case 2:
                                        myList.addLast(JOptionPane.showInputDialog("introduce el valor a agregar"));
                                        JOptionPane.showMessageDialog(null,""+myList);
                                        break;
                                case 3: 
                                        myList.removeFirst();
                                        JOptionPane.showMessageDialog(null,""+myList);
                                        break;
                                case 4:
                                        myList.removeLast();
                                        JOptionPane.showMessageDialog(null,""+myList);
                                        break;
                                case 5:
                                        myList.clear(); 
                                        JOptionPane.showMessageDialog(null,""+myList+"Lista Vacia");
                                        //System.exit(0);
                                case 6:
                                       JOptionPane.showMessageDialog(null,""+myList);        
                        }
                 
                } while(menu!=7);
                System.exit(0);
        
    }
    
}
